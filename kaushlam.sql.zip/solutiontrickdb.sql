-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2020 at 07:00 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `solutiontrickdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_id` int(11) NOT NULL,
  `education_id` int(11) NOT NULL,
  `branch` varchar(150) DEFAULT NULL,
  `abbr` varchar(150) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `display_order` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_id`, `education_id`, `branch`, `abbr`, `status`, `display_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 'Bachelor of Information technology', NULL, 1, 1, '2018-09-20 07:17:54', '2018-09-20 08:16:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `city_id` smallint(5) NOT NULL,
  `country_id` tinyint(3) DEFAULT NULL,
  `state_id` smallint(5) DEFAULT NULL,
  `city_name` varchar(100) DEFAULT NULL,
  `abbr` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`city_id`, `country_id`, `state_id`, `city_name`, `abbr`, `created_at`, `updated_at`, `deleted_at`, `status`) VALUES
(1, 2, 1, 'Lucknow', 'lucknow', '2018-09-26 00:00:00', '0000-00-00 00:00:00', NULL, 1),
(2, 2, 3, 'hbghfg', NULL, '2018-09-17 19:56:41', '2018-09-18 14:40:31', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `country_id` smallint(5) NOT NULL,
  `country_name` varchar(100) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `abbr` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`country_id`, `country_name`, `code`, `abbr`, `created_at`, `updated_at`, `deleted_at`, `status`) VALUES
(2, 'India', 'IN', 'india', '2018-09-26 00:00:00', '0000-00-00 00:00:00', NULL, 1),
(5, 'cxvcxv', 'er', NULL, '2018-09-05 10:32:10', '2018-09-05 10:32:10', NULL, 1),
(6, 'dsjjksdfjlk', 'uy', NULL, '2018-09-05 10:32:57', '2018-09-05 10:32:57', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `educations`
--

CREATE TABLE `educations` (
  `education_id` int(11) NOT NULL,
  `education` varchar(150) DEFAULT NULL,
  `abbr` varchar(150) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `display_order` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `educations`
--

INSERT INTO `educations` (`education_id`, `education`, `abbr`, `status`, `display_order`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'Junior Highschool', 'junior-highschool', 1, 2, '2018-09-19 00:00:00', '2018-09-19 15:32:38', NULL),
(3, 'Highschool (10th)', 'highschool', 1, 3, '2018-09-19 00:00:00', '2018-09-19 15:32:38', NULL),
(4, 'Primary', 'primary', 1, 1, '2018-09-19 00:00:00', '2018-09-19 10:18:57', NULL),
(5, 'Higher Secondary (12th)', 'higher-secondary', 1, 4, '2018-09-19 00:00:00', '2018-09-19 15:32:38', NULL),
(6, 'Graduation', 'graduation', 1, 5, '2018-09-19 00:00:00', '2018-09-19 15:32:38', NULL),
(7, 'Post Graduation', 'post-graduation', 1, 6, '2018-09-19 00:00:00', '2018-09-19 15:32:38', NULL),
(8, 'Doctorate (Phd)', 'doctorate', 1, 7, '2018-09-19 00:00:00', '2018-09-19 15:32:38', NULL),
(9, 'test', NULL, 1, 45, '2018-09-19 10:14:25', '2018-09-19 10:16:47', '2018-09-19 10:16:47');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `job_category_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `job_category_id`, `title`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, 'Electrician', 1, NULL, '0000-00-00 00:00:00', NULL),
(2, NULL, 'Carpenter', 1, NULL, '0000-00-00 00:00:00', NULL),
(3, NULL, 'Painter', 1, NULL, '0000-00-00 00:00:00', NULL),
(4, NULL, 'Plumber', 1, NULL, '0000-00-00 00:00:00', NULL),
(5, NULL, 'Driver', 1, NULL, '0000-00-00 00:00:00', NULL),
(6, NULL, 'DJ', 1, NULL, '0000-00-00 00:00:00', NULL),
(7, NULL, 'Helper', 1, NULL, '0000-00-00 00:00:00', NULL),
(8, NULL, 'Furniture Maker', 1, NULL, '0000-00-00 00:00:00', NULL),
(9, NULL, 'Sweeper', 1, NULL, '0000-00-00 00:00:00', NULL),
(10, NULL, 'POP Worker', 1, NULL, '0000-00-00 00:00:00', NULL),
(11, NULL, 'AC Electrician', 1, NULL, '0000-00-00 00:00:00', NULL),
(12, NULL, 'Mechanics', 1, NULL, '0000-00-00 00:00:00', NULL),
(13, NULL, 'Daily Labour', 1, NULL, '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `sender_user_id` int(11) DEFAULT NULL,
  `receiver_user_id` int(11) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `message` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1' COMMENT '1=New, 2=Assign to user, 3= seen by user, 4= deleted by user'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `category`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'new Post', 'vbvcbvc', 'javascript', 'new-post', '2020-12-18 10:12:21', '2020-12-18 10:12:21'),
(2, 'Test dfdsfsdfvbvcbvcb', 'store working data and machine code.[1][2] A random-access memory device allows data items to be read or written in almost the same amount of time irrespective of the physical location of data inside the memory. In contrast, with other direct-access data storage media such as hard disks, CD-RWs, DVD-RWs and the older magnetic tapes and drum memory, the time required to read and write data items varies significantly depending on their physical locations on the recording medium, due to mechanical limitations such as media rotation speeds and arm movement.', 'css', 'test-dfdsfsdfvbvcbvcb', '2020-12-18 10:14:07', '2020-12-18 10:14:07');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` smallint(5) NOT NULL,
  `role` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role`) VALUES
(1, 'Admin'),
(2, 'User'),
(3, 'Worker');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `state_id` smallint(5) NOT NULL,
  `country_id` tinyint(3) DEFAULT NULL,
  `state_name` varchar(100) DEFAULT NULL,
  `abbr` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`state_id`, `country_id`, `state_name`, `abbr`, `created_at`, `updated_at`, `deleted_at`, `status`) VALUES
(1, 2, 'Uttar Pradesh', 'uttar-pradesh', '2018-09-12 00:00:00', '2018-09-02 06:06:42', NULL, 1),
(2, 6, 'test state', NULL, '2018-09-11 07:26:18', '2018-09-11 18:35:45', NULL, 1),
(3, 2, 'statename2', NULL, '2018-09-11 18:02:29', '2018-09-11 18:02:29', NULL, 1),
(4, 2, 'test state3', NULL, '2018-09-11 18:41:06', '2018-09-11 18:41:06', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `reg_from` tinyint(1) DEFAULT '1' COMMENT '1= E-mail,  2=Phone',
  `fname` varchar(50) DEFAULT ' ',
  `lname` varchar(50) DEFAULT ' ',
  `name` varchar(100) DEFAULT ' ',
  `email` varchar(200) DEFAULT NULL,
  `phone` varchar(20) DEFAULT 'NA ',
  `dob` varchar(50) DEFAULT 'NA',
  `role_id` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1=Admin , 2=User, 3 = Worker',
  `password` varchar(100) DEFAULT NULL,
  `activation_key` varchar(200) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=active, 0=inactive',
  `remember_token` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `reg_from`, `fname`, `lname`, `name`, `email`, `phone`, `dob`, `role_id`, `password`, `activation_key`, `last_login`, `created_at`, `updated_at`, `deleted_at`, `status`, `remember_token`) VALUES
(2, 1, 'sdsafsa', 'fsfsafsa', 'sdsafsa fsfsafsa', 'psunandap@gmail.com', 'NA', 'NA', 1, '$2y$10$IZynQbzquQVkCRrKv96myu53UDTgg1bEzoeB0BkSdhrGg7WDTuemy', 'fce4718601352ee2c99063f9998fee2cc4448fa1539dc67a2ea280c2990f67f7', '2020-12-18 20:08:18', '2018-08-31 09:32:38', '2020-12-18 20:08:18', '2018-09-21 18:34:37', 1, NULL),
(3, 1, 'erfewr', 'ewrewr', 'erfewr ewrewr', 'psunandap1@gmail.com', 'NA', 'NA', 1, '$2y$10$IZynQbzquQVkCRrKv96myu53UDTgg1bEzoeB0BkSdhrGg7WDTuemy', '960817ff6142231bf4324b243db3173f0a7a4bf0dbedc382809f2d4b97d14998', '2020-12-18 20:09:26', '2018-08-31 10:02:19', '2020-12-18 20:09:26', NULL, 1, NULL),
(14, 1, NULL, NULL, 'pintoogayra', 'psunandap5@gmail.com', 'NA', 'NA', 1, '$2y$10$Hr2V9dVX272OQQT7tRN2BONJ11C7/VAsK99E9n68mPluqbMiE9eMS', '4ca1205ea08f7c24abe26ff706ba53c728dd47accbf97f806a080874c80a4bd7', '2018-09-21 23:14:42', '2018-08-31 10:43:56', '2018-09-21 23:14:42', NULL, 1, 'rz4sAFV4YACmhur2vTfYP2uIQMujvPuZ49Xe8GICO5Gqna6Gy7J0yTeYFPG7'),
(15, 1, 'dffdsfds', 'dfdsfd', 'dffdsfds dfdsfd', 'stadmin@gmail.com', 'NA', 'NA', 1, '$2y$10$IZynQbzquQVkCRrKv96myu53UDTgg1bEzoeB0BkSdhrGg7WDTuemy', '4ca1205ea08f7c24abe26ff706ba53c728dd47accbf97f806a080874c80a4bd7', '2020-12-18 20:11:38', '2018-08-31 10:43:56', '2020-12-18 20:11:38', NULL, 1, 'yXbXEOBT73I6lv0nli70ftwmFznybbOuvCH1sL6axJFj1CXnVTdwjUIsPBMg'),
(16, 1, 'fname', 'lanae', NULL, 'psunandap12@gmail.com', 'NA ', 'NA', 1, '$2y$10$IZynQbzquQVkCRrKv96myu53UDTgg1bEzoeB0BkSdhrGg7WDTuemy', NULL, '2020-12-18 20:11:26', '2018-09-21 17:15:19', '2020-12-18 20:11:26', '2018-09-21 18:34:58', 1, NULL),
(17, 1, ' ', ' ', 'Neha Gautam', 'test@gmail.com', 'NA ', 'NA', 1, '$2y$10$IZynQbzquQVkCRrKv96myu53UDTgg1bEzoeB0BkSdhrGg7WDTuemy', NULL, '2020-12-18 20:07:57', '2020-12-18 14:25:31', '2020-12-18 20:07:57', NULL, 1, '9llH0lZafqy7hpdbzm3pzFUemR31smoC3Kddoz5rsqtr6FxoqzJ2YHX6a8NJ');

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `country_id` int(11) DEFAULT '0',
  `state_id` int(11) DEFAULT '0',
  `city_id` int(11) DEFAULT '0',
  `address` varchar(150) DEFAULT NULL,
  `country_ip` int(11) DEFAULT NULL,
  `state_ip` varchar(100) DEFAULT NULL,
  `city_ip` varchar(100) DEFAULT NULL,
  `adress_ip_org` varchar(150) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_work_details`
--

CREATE TABLE `user_work_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `job_id` smallint(3) NOT NULL,
  `education_id` int(11) DEFAULT NULL,
  `work_description` text,
  `description` text,
  `service_charges` text,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `zipcodes`
--

CREATE TABLE `zipcodes` (
  `zipcode_id` smallint(5) NOT NULL,
  `country_id` tinyint(3) DEFAULT NULL,
  `state_id` smallint(5) DEFAULT NULL,
  `city_id` smallint(5) DEFAULT NULL,
  `zipcode` varchar(100) DEFAULT NULL,
  `abbr` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zipcodes`
--

INSERT INTO `zipcodes` (`zipcode_id`, `country_id`, `state_id`, `city_id`, `zipcode`, `abbr`, `created_at`, `updated_at`, `deleted_at`, `status`) VALUES
(1, 2, 1, 1, '226004', NULL, '2018-09-18 18:33:17', '2018-09-18 18:34:14', NULL, 1),
(2, 2, 1, 1, '226001', NULL, '2018-09-19 09:34:02', '2018-09-19 09:34:02', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `educations`
--
ALTER TABLE `educations`
  ADD PRIMARY KEY (`education_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_title_unique` (`title`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zipcodes`
--
ALTER TABLE `zipcodes`
  ADD PRIMARY KEY (`zipcode_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `city_id` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `country_id` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `educations`
--
ALTER TABLE `educations`
  MODIFY `education_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `state_id` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `zipcodes`
--
ALTER TABLE `zipcodes`
  MODIFY `zipcode_id` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
